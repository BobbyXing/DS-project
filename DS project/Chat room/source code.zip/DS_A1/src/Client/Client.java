// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/04/19

package Client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	static BufferedReader input = null;
	static BufferedWriter output = null;
	static Socket client = null;
	public static void main(String[] args) {
		String serverAddress = args[0];
		String strPort = args[1];
		int intPort = Integer.parseInt(strPort);
		try {
			client = new Socket(serverAddress, intPort);
			System.out.println("Client connection established.");
			ClientUI clientUI = new ClientUI();
			clientUI.start();
			InputStreamReader inputreader = null;
			OutputStreamWriter outputwriter = null;
			try {
				inputreader = new InputStreamReader(client.getInputStream(), "UTF-8");
				outputwriter = new OutputStreamWriter(client.getOutputStream(), "UTF-8");
				input = new BufferedReader(inputreader);
				output = new BufferedWriter(outputwriter);
			} catch (NullPointerException e) { 
				System.out.println("NullPointerException Error, No receiving any request from Server.");
			} catch (IOException e) {
				System.out.println("IOException: " + e.getMessage());
			}
		} catch (UnknownHostException e) {
			System.out.println("UnknownHostException Error, Check your Server address!");
		} catch (IOException e) {
			System.out.println("IOException: " + e.getMessage());
			System.out.println("Check Port!");
		}
		
	}

}
