// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/04/19

package Client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;


public class ClientUI extends Thread {

	private JFrame frame;
	private JTextField wordInput;
	private JTextField meaningInput;
	private JTextArea textOutput;
	private JTextField fileName;
	private JTextField exportFile;
	
	public void run() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientUI window = new ClientUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					System.out.println("IOException Error.");
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ClientUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 1110, 748);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Word:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblNewLabel.setBounds(42, 127, 84, 38);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblMeaning = new JLabel("Meaning:");
		lblMeaning.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblMeaning.setBounds(10, 217, 116, 38);
		frame.getContentPane().add(lblMeaning);
		
		wordInput = new JTextField();
		wordInput.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		wordInput.setBounds(136, 133, 814, 38);
		frame.getContentPane().add(wordInput);
		wordInput.setColumns(10);
		
		meaningInput = new JTextField();
		meaningInput.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		meaningInput.setColumns(10);
		meaningInput.setBounds(136, 217, 814, 38);
		frame.getContentPane().add(meaningInput);
		
		JLabel lblNewLabel_1 = new JLabel("Type your word here.");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(160, 97, 156, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Type the meaning of a word you want to add here.");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(160, 187, 395, 20);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JButton btnNewButton = new JButton("Add New Word");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String inputStr = "Add-SPL-" + wordInput.getText() + "-SPL-" + meaningInput.getText() + "\n";
				try {
					Client.output.write(inputStr);
					Client.output.flush();
					String feedback = Client.input.readLine();
					textOutput.setText(feedback);
					System.out.println(feedback);
				} catch (IOException e1) {
					System.out.println("IOException: " + e1.getMessage());
				} catch (NullPointerException e1) {
					System.out.println("NullPointerException Error, check your connection.");
				} 
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton.setBounds(342, 302, 196, 38);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnDelete = new JButton("Delete the Word");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String inputStr = "Delete-SPL-" + wordInput.getText() + "-SPL-" + meaningInput.getText() + "\n";
				try {
					Client.output.write(inputStr);
					Client.output.flush();
					String feedback = Client.input.readLine();
					textOutput.setText(feedback);
					System.out.println(feedback);
				} catch (IOException e1) {
					System.out.println("IOException: " + e1.getMessage());
				} catch (NullPointerException e1) {
					System.out.println("NullPointerException Error, check your connection.");
				}
				
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnDelete.setBounds(548, 302, 196, 38);
		frame.getContentPane().add(btnDelete);
		
		JButton btnUpdataAWords = new JButton("Updata the Meaning");
		btnUpdataAWords.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String inputStr = "Update-SPL-" + wordInput.getText() + "-SPL-" + meaningInput.getText() + "\n";
				try {
					Client.output.write(inputStr);
					Client.output.flush();
					String feedback = Client.input.readLine();
					textOutput.setText(feedback);
					System.out.println(feedback);
				} catch (IOException e1) {
					System.out.println("IOException: " + e1.getMessage());
				} catch (NullPointerException e1) {
					System.out.println("NullPointerException Error, check your connection.");
				}
			}
		});
		btnUpdataAWords.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnUpdataAWords.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnUpdataAWords.setBounds(754, 302, 196, 38);
		frame.getContentPane().add(btnUpdataAWords);
		
		JButton btnQueryAWord = new JButton("Query the Word");
		btnQueryAWord.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String inputStr = "Query-SPL-" + wordInput.getText() + "-SPL-" + meaningInput.getText() + "\n";
				try {
					Client.output.write(inputStr);
					Client.output.flush();
					String feedback = Client.input.readLine();
					textOutput.setText(feedback);
					System.out.println(feedback);
				} catch (IOException e1) {
					System.out.println("IOException: " + e1.getMessage());
				} catch (NullPointerException e1) {
					System.out.println("NullPointerException Error, check your connection.");
				}
			}
		});
		btnQueryAWord.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnQueryAWord.setBounds(136, 302, 196, 38);
		frame.getContentPane().add(btnQueryAWord);
		
		textOutput = new JTextArea();
		textOutput.setLineWrap(true);
		textOutput.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		textOutput.setEditable(false);
		textOutput.setBounds(136, 533, 814, 139);
		frame.getContentPane().add(textOutput);
		
		JLabel lblNewLabel_2 = new JLabel("Client Dictionary");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 60));
		lblNewLabel_2.setBounds(309, 10, 435, 88);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnImportFile = new JButton("Import File");
		btnImportFile.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Client.output.write("ImportFile-SPL-" + fileName.getText() + "\n");
					Client.output.flush();
					String feedback = Client.input.readLine();
					textOutput.setText(feedback);
					System.out.println(feedback);
				} catch (IOException e1) {
					System.out.println("IOException: " + e1.getMessage());
				} catch (NullPointerException e1) {
					System.out.println("NullPointerException Error, check your connection.");
				}
			}
		});
		btnImportFile.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnImportFile.setBounds(136, 378, 196, 38);
		frame.getContentPane().add(btnImportFile);
		
		fileName = new JTextField();
		fileName.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		fileName.setBounds(342, 378, 608, 38);
		frame.getContentPane().add(fileName);
		fileName.setColumns(10);
		
		JLabel lblNewLabel_1_2 = new JLabel("Type your the file name you want to import here.");
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_1_2.setBounds(365, 348, 578, 20);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		JButton export = new JButton("Export File");
		export.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Client.output.write("ExportFile-SPL-" + exportFile.getText() + "\n");
					Client.output.flush();
					String feedback = Client.input.readLine();
					textOutput.setText(feedback);
					System.out.println(feedback);
				} catch (IOException e1) {
					System.out.println("IOException: " + e1.getMessage());
				} catch (NullPointerException e1) {
					System.out.println("NullPointerException Error, check your connection.");
				}
			}
		});
		export.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		export.setBounds(136, 456, 196, 38);
		frame.getContentPane().add(export);
		
		exportFile = new JTextField();
		exportFile.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		exportFile.setColumns(10);
		exportFile.setBounds(342, 456, 608, 38);
		frame.getContentPane().add(exportFile);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Type your the file name you want to export here.");
		lblNewLabel_1_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_1_2_1.setBounds(365, 426, 578, 20);
		frame.getContentPane().add(lblNewLabel_1_2_1);
	}
}
