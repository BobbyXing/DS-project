// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/04/19

package Server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Server {
	
	static HashMap<String, String> dictionary = new HashMap<String, String>();
	static int clientNumber = 0;
	static String fileName;
	public static void readDict(String filename) throws IOException {
		File dictFile = new File(filename);
		InputStreamReader input = new InputStreamReader(new FileInputStream(dictFile), "UTF-8");
		BufferedReader bufferReader =  new BufferedReader(input);
		String line = null;
		while ((line = bufferReader.readLine()) != null) {
			String word = line.split("-SPL-")[0];
			String meaning = line.split("-SPL-")[1];
			dictionary.put(word, meaning);
		}
		input.close();
		bufferReader.close();
	}
	
	public static void writeDic(String filename) throws IOException {
		File dictFile = new File(filename);
		BufferedWriter bufferWriter = new BufferedWriter(new FileWriter(dictFile));
		Set<String> set = dictionary.keySet();
		Iterator<String> it = set.iterator();
		while(it.hasNext()) {
			String word = it.next();
			String meaning = dictionary.get(word);
			bufferWriter.write(word + "-SPL-" + meaning + "\n");
		}
		bufferWriter.flush();
		bufferWriter.close();
	}
	
	
	public static void main(String[] args) {
		ServerSocket serverSocket = null;;
		String strPort = args[0];
		String file = args[1];
		if (file.contains(".")) {
			String name2 = file.replace(".", "-");
			String[] formate = name2.split("-");
			if (formate[1].equals("txt")) {
				fileName = file;
			} else {
				System.out.println("Only support \"txt\" file but got \"" + formate[1] + "\"");
			}
		} else {
			fileName = file+".txt";
		}
		int intPort = Integer.parseInt(strPort);
		try {
			serverSocket = new ServerSocket(intPort);
			ServerUI serverUI = new ServerUI();
			serverUI.start();
			// always running
			// using thread-per-connection
			
			while (true) {
				// make connection
				Socket socket = null;
				System.out.println("Server Ready, waiting for response on port: " + strPort);
				try {
					socket = serverSocket.accept();
					File dictFile = new File(fileName);
					dictFile.createNewFile();
					readDict(fileName);
					clientNumber++;
					ThreadConnection connection = new ThreadConnection(socket, dictionary);
					connection.start();
					System.out.println("Server received new Client connection on port " + strPort + ", Client number: " + clientNumber);
				} catch (IOException e) {
					System.out.println("Failed to connect to client socket!");
				} catch (NullPointerException e) {
					System.out.println("NullPointerException Error, serverSocket is null.");
				} 
			}
		} catch (IOException e) {
			System.out.println("IOException : " + e.getMessage());
		}	
	}
}
