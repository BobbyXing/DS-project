// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/04/19

package Server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class ThreadConnection extends Thread{
	HashMap<String, String> dictionary = new HashMap<String, String>();
	Socket socket = null;
	BufferedReader input; // input from client
	BufferedWriter output; // output to client
	static String uiOutput = null;
	static String inputString;
	@Override
	public void run() {
		int i = Server.clientNumber;
		try {
			while (true) {
				inputString = input.readLine();
				uiOutput = inputString;
				String[] splitStr = inputString.split("-SPL-");
				String method = splitStr[0];
				String meaning = null;
				String word = null;
				if (splitStr.length == 3) {
					meaning = splitStr[2];	
					word = splitStr[1];
				} else if (splitStr.length == 2) {
					word = splitStr[1];
				}
				switch (method) {
				case "Add":
					add(word,meaning,i);
					break;
				case "Delete":
					delete(word,i);
					break;
				case "Update":
					update(word,meaning,i);
					break;
				case "Query":
					query(word,i);
					break;
				case "ImportFile":
					importFile(word,i);
					break;
				case "ExportFile":
					export(word,i);
					break;
				default:
					break;
				}
			}
		} catch (IOException e) {
			System.out.println("Client " + i + " Disconnect, Closed...");
		}
		super.run();
	}
	// make connection to each client based on socket
	public ThreadConnection(Socket socket, HashMap<String, String> dictionary) {
		this.socket = socket;
		this.dictionary =  dictionary;
		InputStreamReader isr = null;
		OutputStreamWriter osw = null;
		try {
			isr = new InputStreamReader(socket.getInputStream(), "UTF-8");
			osw = new OutputStreamWriter(socket.getOutputStream(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			System.out.println("UnsupportedEncodingException: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IOException: " + e.getMessage());
		}
		input = new BufferedReader(isr);
		output =  new BufferedWriter(osw);
	}
	
	public synchronized void query(String word, int i) throws IOException {
		if (word != null) {
			if (dictionary.containsKey(word)) {
				String meaning = dictionary.get(word);
				ServerUI.row[0] = i;
				ServerUI.row[1] = "Query";
				ServerUI.row[2] = word;
				ServerUI.row[3] = meaning;
				ServerUI.model.addRow(ServerUI.row);
				output.write("The meaning of the Word \"" + word + "\" is: " + meaning + "\n");
				output.flush();
			} else {
				output.write("Word \"" + word + "\" is not in the dictionary, cannot query a not exist word!\n");
				output.flush();
			}
		} else {
			output.write("Please type your word in the word block for querying!\n");
			output.flush();
		}
	}
	
	public synchronized void add(String word, String meaning, int i) throws IOException {
		if (word != null) {
			if (dictionary.containsKey(word)) {
				output.write("Word \"" + word + "\" already in the dictionary, you cannot add it twice!\n");
				output.flush();
			}  else if (meaning == null){
				output.write("Could not add the word \"" + word + "\" with no meaning, "
						+ "Please type the meaning of the word in the meaning bolck\n");
				output.flush();
			} else {
				dictionary.put(word, meaning);
				ServerUI.row[0] = i;
				ServerUI.row[1] = "Add";
				ServerUI.row[2] = word;
				ServerUI.row[3] = meaning;
				ServerUI.model.addRow(ServerUI.row);
				Server.writeDic(Server.fileName);
				output.write("Word \"" + word + "\" add successfully!\n");
				output.flush();
			}
		} else {
			output.write("Please type your word in the word block for adding!\n");
			output.flush();
		}	
	}
	public synchronized void delete(String word, int i) throws IOException {
		if (word != null) {
			if (dictionary.containsKey(word)) {
				dictionary.remove(word);
				ServerUI.row[0] = i;
				ServerUI.row[1] = "Delete";
				ServerUI.row[2] = word;
				ServerUI.model.addRow(ServerUI.row);
				Server.writeDic(Server.fileName);
				output.write("Word \"" + word + "\" delete successfully!\n");
				output.flush();
			} else {
				output.write("Word \"" + word + "\" is not in the dictionary, cannot delete a not exist word!\n");
				output.flush();
			}
		} else {
			output.write("Please type your word in the word block for deleting!\n");
			output.flush();
		}
	}
	public synchronized void update(String word, String meaning, int i) throws IOException {
		if (word != null) {
			if (dictionary.containsKey(word)) {
				dictionary.remove(word);
				dictionary.put(word, meaning);
				ServerUI.row[0] = i;
				ServerUI.row[1] = "Update";
				ServerUI.row[2] = word;
				ServerUI.row[3] = meaning;
				ServerUI.model.addRow(ServerUI.row);
				Server.writeDic(Server.fileName);
				output.write("Word \"" + word + "\" update successfully!\n");
				output.flush();
			} else if (meaning == null){
				output.write("Could not update the word \"" + word + "\" with no meaning, "
						+ "Please type the meaning of the word in the meaning bolck\n");
				output.flush();
			} else {
				output.write("Word \"" + word + "\" is not in the dictionary, cannot update a not exist word!\n");
				output.flush();
			}
		} else {
			output.write("Please type your word in the word block for updating!\n");
			output.flush();
		}
	}
	
	public synchronized void importFile(String filename, int i) throws IOException {
		if (filename != null) {
			File  file = new File(filename);
			if (file.exists()) {
				String name2 = filename.replace(".", "-");
				String[] formate = name2.split("-");
				if (formate[1].equals("txt")) {
					InputStreamReader input = new InputStreamReader(new FileInputStream(file), "UTF-8");
					BufferedReader bufferReader =  new BufferedReader(input);
					String line = null;
					int lineNum = 0;
					boolean hasError = false;
					while ((line = bufferReader.readLine()) != null) {
						lineNum++;
						try {
							String word = line.split("-")[0];
							String meaning = line.split("-")[1];
							dictionary.put(word, meaning);	
						} catch (ArrayIndexOutOfBoundsException e) {
							hasError = true;
							output.write("ArrayIndexOutOfBoundsException Error,"
									+ " Check your coding formate in file \"" + file +"\"" 
									+ " for line " + lineNum + "\n");
							output.flush();
						}
					} 
					if (!hasError) {
						ServerUI.row[0] = i;
						ServerUI.row[1] = "ImportFile";
						ServerUI.row[2] = filename ;
						ServerUI.model.addRow(ServerUI.row);
						output.write("file \"" + filename + "\" import successfully!\n");
						output.flush();
					}
					bufferReader.close();
				} else {
					output.write("file \"" + filename + "\" formate are not right, should be \"txt\", but got \"" + formate[1] + "\".\n");
					output.flush();
				}
			}  else {
				output.write("There is no such file called \"" + filename + "\", please check your filename!\n");
				output.flush();
			}
		} else {
			output.write("Filename can not be empty, Please type the import file name in the import block!\n");
			output.flush();
		}
	}
	public synchronized void exportFile(String filename) throws IOException {
		File exportFile = new File(filename);
		exportFile.createNewFile();
		BufferedWriter bufferWriter = new BufferedWriter(new FileWriter(exportFile));
		Set<String> set = dictionary.keySet();
		Iterator<String> it = set.iterator();
		while(it.hasNext()) {
			String word = it.next();
			String meaning = dictionary.get(word);
			bufferWriter.write(word + "-" + meaning + "\n");
		}
		bufferWriter.flush();
		bufferWriter.close();
	}
	public synchronized void export(String filename, int i) throws IOException {
		if (filename == null) {
			output.write("Filename can not be empty, Please type the export file name in the export block!\n");
			output.flush();
		} else if (!filename.contains(".")) {
			filename = filename + ".txt";
			exportFile(filename);
			ServerUI.row[0] = i;
			ServerUI.row[1] = "ExportFile";
			ServerUI.row[2] = filename;
			ServerUI.model.addRow(ServerUI.row);
			output.write("Export successfully! filename is: \"" + filename + "\"\n");
			output.flush();
		} else {
			String name2 = filename.replace(".", "-");
			String[] formate = name2.split("-");
			if (formate[1].equals("txt")) {
				// operation here
				ServerUI.row[0] = i;
				ServerUI.row[1] = "ExportFile";
				ServerUI.row[2] = filename;
				ServerUI.model.addRow(ServerUI.row);
				exportFile(filename);
				output.write("Export successfully! filename is: \"" + filename + "\"\n");
				output.flush();
			} else {
				output.write("Only support exporting to a \"txt\" file but got: \"" + formate[1] + "\"\n");
				output.flush();
			}
		}
	}

}
