// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/04/19

package Server;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class ServerUI extends Thread{

	private JFrame frame;
	private JTable table;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	static Object[] row = new Object[4];
	static DefaultTableModel model; 
	/**
	 * Launch the application.
	 */
	public void run() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ServerUI window = new ServerUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					System.out.println("Exception: " + e.getMessage());
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ServerUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 1109, 745);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 135, 1073, 440);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		scrollPane.setViewportView(table);
		Object[] header = {"Client number", "Operation","Word/Filename","Meaning"};
		model = new DefaultTableModel();
		model.setColumnIdentifiers(header);
		table.setModel(model);
		table.setRowHeight(30);
		lblNewLabel = new JLabel("Server Dictionary");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 60));
		lblNewLabel.setBounds(337, 20, 482, 94);
		frame.getContentPane().add(lblNewLabel);
		
		
		lblNewLabel_1 = new JLabel("Client operation History:");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(26, 103, 164, 22);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton_1_1 = new JButton("Clear Dictionary");
		btnNewButton_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Server.dictionary.clear();
				System.out.println("Dictionary clear successfully");
				try {
					Server.writeDic(Server.fileName);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					System.out.println("IOException: " + e1.getMessage());
				}
			}
		});
		btnNewButton_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		btnNewButton_1_1.setBounds(10, 609, 1073, 38);
		frame.getContentPane().add(btnNewButton_1_1);
	}
}
