// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/05/30

package Client;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;


public class Client {
    public static DataInputStream dis = null; // input from client
    public static DataOutputStream dos = null; // output to client
    static Socket client = null;
    public static ClientUI clientUI;
    public static String getMess;
    public static String chatString  = "";
    public static String userName;
    public static String port;
    public static String address;
    public static List<String> userList;

    public static void main(String[] args) {
        try {
			address = args[0];
			port = args[1];
			userName = args[2];
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}      
    
        try {
            client = new Socket(address, Integer.parseInt(port));
            System.out.println("Client connection established.");
        } catch (UnknownHostException e) {
            System.out.println("UnknownHostException Error, Check your Server address!");
        } catch (IOException e) {
            System.out.println("IOException: " + e.getMessage());
            System.out.println("Check Port!");
        }
        try {
            dis = new DataInputStream(client.getInputStream());
            dos = new DataOutputStream(client.getOutputStream());
            dos.writeUTF("Ask-" + userName);
            dos.flush();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("Exception " + e.getMessage());
        }
        try {
            while ((getMess = dis.readUTF()) != null) {
                String[] strList = getMess.split("-",2);
                if (strList[0].equals("Ask")) {
                	// feedback is allowed, join the white board
                    if (strList[1].equals("Allowed")){
                        dos.writeUTF("JoinIn-" + "bobby");
                        dos.flush();
                        clientUI = new ClientUI();
                        System.out.println(userName + "Join!");
                        JOptionPane.showMessageDialog(clientUI.frame,"You are allowed to join!" );
                    // if it's rejected, show rejected message window
                    } else if (strList[1].equals("Rejected")){
                    	JOptionPane.showMessageDialog(null,"You are rejected to join!" );
                        client.close();
                        System.exit(0);
                     // is user already exist, show user exit window.
                    } else if (strList[1].equals("Dup")){
                        JOptionPane.showMessageDialog(null,"User name exit!" );
                        client.close();
                        System.exit(0);
                    }
                // if feedback is Paint, update the paint list and repaint
                } else if (strList[0].equals("Paint")){
                    ClientUI.allListener.update(strList[1]);
                    ClientUI.drawArea.repaint();
                // if feedback is Chat, update the chat list and reset chat box
                } else if (strList[0].equals("Chat")) {
                    chatString = strList[1];
                    ClientUI.setChat(strList[1]);
                // if feedback is User, update the user list and reset User lists
                } else if (strList[0].equals("User")) {
                    userList.add(strList[1]);
                    Object[] a = userList.toArray();
                    clientUI.list.setListData(a);
                // if feedback is Kick, show message and close all.
                } else if (strList[0].equals("Kick")) {
                    JOptionPane.showMessageDialog(clientUI.frame,"You have been kicked out!" );
                    client.close();
                    clientUI.frame.dispose();
                    System.exit(0);
                // if feedback is Close, show message and close all
                } else if (strList[0].equals("Close")) {
                    JOptionPane.showMessageDialog(clientUI.frame,"Disconnected from Manager!" );
                    client.close();
                    clientUI.frame.dispose();
                    System.exit(0);
                // if feedback is new, remove all draw list, create a new draw area.
                } else if (strList[0].equals("New")) {
                    ClientUI.drawArea.removeAll();
                    ClientUI.drawArea.updateUI();
                    ClientUI.allListener.clearRecord();
                } else if (strList[0].equals("Newone")) {
                    userList = new ArrayList<>();
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("Exception " + e.getMessage());
        }
    }
}
