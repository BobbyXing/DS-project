// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/05/30
package Client;


import javax.swing.JFrame;
import javax.swing.WindowConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JList;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.JLabel;

public class ClientUI {

    JFrame frame;
    private JTextField chatText;
    public static JList<Object> list;
    public static AllListener allListener;
    public static Repaint drawArea;
    public static JTextArea chatOutput;
    /**
     * Create the application.
     */
    public ClientUI() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     * @wbp.parser.entryPoint
     */
    private void initialize() {
        frame = new JFrame();
        frame.setTitle("Guest White Board " + Client.userName);
        frame.setBounds(100, 100, 1092, 695);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                try {
                    Client.dos.writeUTF("Close-" + Client.userName);
                    frame.dispose();
                    Client.client.close();
                    System.exit(0);
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    System.out.println("IOException: " + e.getMessage());
                }
            }
        });

        chatOutput = new JTextArea();
        chatOutput.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        chatOutput.setEditable(false);
        JScrollPane chatScroll = new JScrollPane(chatOutput);
        chatScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        chatScroll.setBounds(717, 51, 259, 554);
        frame.getContentPane().add(chatScroll);

        chatText = new JTextField();
        chatText.setBounds(717, 615, 168, 31);
        frame.getContentPane().add(chatText);
        chatText.setColumns(10);

        JButton sendBtn = new JButton("send");
        sendBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                Client.chatString += Client.userName + ":" + "\n" + chatText.getText() + "\n";
                setChat(Client.chatString);
                try {
                    Client.dos.writeUTF("Chat-" + Client.chatString);
                    Client.dos.flush();
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
            @Override
            public void mouseReleased(MouseEvent e) {
                chatText.setText("");
            }
        });
        sendBtn.setFont(new Font("Times New Roman", Font.BOLD, 18));
        sendBtn.setBounds(895, 615, 171, 31);
        frame.getContentPane().add(sendBtn);

        // draw Area JPanel
        drawArea = new Repaint();
        drawArea.setBackground(Color.WHITE);

        drawArea.setBounds(124, 51, 583, 595);
        frame.getContentPane().add(drawArea);

        //---------------------- Draw Line, Circle, Triangle, Rectangle, Button--------//
        JButton lineBtn = new JButton("Line");			// line
        lineBtn.addMouseListener(new MouseAdapter() { 	// add click listener to lineBtn
            @Override
            public void mouseClicked(MouseEvent e) {
                allListener.setType("Line");
            }
        });
        lineBtn.setBounds(10, 263, 104, 31);
        frame.getContentPane().add(lineBtn);

        JButton circleBtn = new JButton("Circle");		// circle
        circleBtn.addMouseListener(new MouseAdapter() { // add click listener to circleBtn
            @Override
            public void mouseClicked(MouseEvent e) {
                allListener.setType("Circle");
            }
        });
        circleBtn.setBounds(10, 304, 104, 31);
        frame.getContentPane().add(circleBtn);

        JButton triBtn = new JButton("Triangle");		// triangle
        triBtn.addMouseListener(new MouseAdapter() { 	// add click listener to triBtn
            @Override
            public void mouseClicked(MouseEvent e) {
                allListener.setType("Triangle");
            }
        });
        triBtn.setBounds(10, 345, 104, 31);
        frame.getContentPane().add(triBtn);

        JButton recBtn = new JButton("Rectangle");		// rectangle
        recBtn.addMouseListener(new MouseAdapter() { 	// add click listener to recBtn
            @Override
            public void mouseClicked(MouseEvent e) {
                allListener.setType("Rectangle");
            }
        });
        recBtn.setBounds(10, 386, 104, 31);
        frame.getContentPane().add(recBtn);

        JButton Tbtn = new JButton("A");				// text
        Tbtn.addMouseListener(new MouseAdapter() {		// add click listener to Tbtn
            @Override
            public void mouseClicked(MouseEvent e) {
                allListener.setType("A");
            }
        });
        Tbtn.setBounds(10, 427, 104, 31);
        frame.getContentPane().add(Tbtn);

        JButton mouBtn = new JButton("Mouse");
        mouBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                allListener.setType("Mouse");
            }
        });
        mouBtn.setBounds(10, 195, 104, 31);
        frame.getContentPane().add(mouBtn);


        //---------------------- Draw Line, Circle, Triangle, Rectangle, Button, A --------//

        JButton corBtn = new JButton("More Color");
        corBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                final JFrame jf = new JFrame("Color Penal");
                jf.setSize(300,300);
                jf.setLocationRelativeTo(null);
                jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                Color curColor = JColorChooser.showDialog(jf,"Choose color",null);
                if (curColor != null) {
                    AllListener.color = curColor;
                }
            }
        });
        corBtn.setBounds(10, 154, 104, 31);
        frame.getContentPane().add(corBtn);

        // add listener to the Panel
        allListener = new AllListener(frame);
        frame.setVisible(true);
        drawArea.addMouseListener(allListener);
        drawArea.addMouseMotionListener(allListener);
        allListener.setG(drawArea.getGraphics());
        drawArea.setList(allListener.getRecord());

        list = new JList<Object>();
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setBounds(986, 51, 80, 554);
        frame.getContentPane().add(list);

        JLabel lblNewLabel = new JLabel("Draw Pad");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblNewLabel.setBounds(374, 10, 88, 31);
        frame.getContentPane().add(lblNewLabel);

        JLabel lblChat = new JLabel("Chat");
        lblChat.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblChat.setBounds(808, 10, 52, 31);
        frame.getContentPane().add(lblChat);

        JLabel lblUsers = new JLabel("Users");
        lblUsers.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblUsers.setBounds(988, 10, 58, 31);
        frame.getContentPane().add(lblUsers);



    }
    
    // set information in user list 
    public static void setListData(Object[] usernames) {
        list.setListData(usernames);
    }
    
    // set information in the chat box 
    public static void setChat(String outPut) {
        chatOutput.setText(outPut);
    }
}
