// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/05/30
package Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;



public class Server {

    public static List<ThreadConnection> connections = new ArrayList<>();
    public static List<String> usernames = new ArrayList<>();
    public static List<String> guestName = new ArrayList<>();
    public static ServerUI serverUI;
    public static String mUser;
    public static ServerSocket serverSocket;
    public static String port;
    public static void main(String[] args) {
        try {
			port = args[0];
			mUser = args[1];
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
    	
        serverSocket = null;
        ThreadConnection connection = null;
        System.out.println("Opening ServerUI...");
        serverUI = new ServerUI();
        usernames.add("(*)" + mUser);
        serverUI.setListData(usernames.toArray());
        try {
            serverSocket = new ServerSocket(Integer.parseInt(port));
            Socket client;
            while (true) {
                // make connection
                client = serverSocket.accept();
                
                connection = new ThreadConnection(client);
                connections.add(connection);
                System.out.println("Server Ready, waiting for response on port: 4444");
                connection.start();

            }
        } catch (IOException e) {
            System.out.println("IOException : " + e.getMessage());
        }
    }
}
