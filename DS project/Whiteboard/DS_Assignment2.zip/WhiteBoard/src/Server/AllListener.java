// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/05/30
package Server;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class AllListener implements ActionListener, MouseListener, MouseMotionListener{

    Graphics2D g;
    JFrame frame;
    int startX, startY, endX, endY;
    int t = 4;
    Object type = "Mouse";
    public static Color color = Color.BLACK;
    String rgb = "0-0-0";
    String record;
    private ArrayList<String> recordList = new ArrayList<>();

    public AllListener() {

    }

    public AllListener(JFrame frame) {
        this.frame = frame;
    }
    public void setType(Object type) {
        this.type = type;
    }
    public Object getType() {
        return this.type;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        startX = e.getX();
        startY = e.getY();
        g.setColor(color);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        endX = e.getX();
        endY = e.getY();
        rgb = getColor(color);
        if (this.type.equals("Line")) {
            g.setStroke(new BasicStroke(t));
            g.drawLine(startX, startY, endX, endY);
            record = recordMessage("Line", t, rgb, startX, startY, endX, endY);
            recordList.add(record);
        } else if (this.type.equals("Circle")) {
            g.setStroke(new BasicStroke(t));
            g.drawOval(startX, startY, Math.abs(endX - startX), Math.abs(endY - startY));
            record = recordMessage("Circle", t, rgb, startX, startY, endX, endY);
            recordList.add(record);
        } else if (this.type.equals("Triangle")) {
            g.setStroke(new BasicStroke(t));
            // p1 ((startX + endX) / 2, startY)
            // p2 (startX, endY)
            // p3 (endX, endY)
            g.drawLine((startX + endX) / 2, startY, endX, endY);
            g.drawLine((startX + endX) / 2, startY, startX, endY);
            g.drawLine(startX, endY, endX, endY);
            record = recordMessage("Triangle", t, rgb, startX, startY, endX, endY);
            recordList.add(record);
        } else if (this.type.equals("Rectangle")) {
            g.setStroke(new BasicStroke(t));
            g.drawRect(startX, startY, Math.abs(endX - startX), Math.abs(endY - startY));
            record = recordMessage("Rectangle", t, rgb, startX, startY, endX, endY);
            recordList.add(record);
        } else if (this.type.equals("A")) {
            String text = JOptionPane.showInputDialog("Please Enter Input Text");
            if (text != null) {
                Font f = new Font(null, Font.PLAIN, this.t + 20);
                g.setFont(f);
                g.drawString(text, startX, startY);
                record = textMessage("A", t, rgb, startX, startY, text);
                recordList.add(record);
            }
        } else {
            return;
        }
        try {
            ConnectionManager.sendToAll("Paint-" + record);
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            System.out.println("IOException: " + e1.getMessage());
        }
    }

    // Return the communication format for painting a shape
    public String recordMessage(String oper, int t, String rgb, int x1, int y1, int x2, int y2) {
        return (oper + "-" + t + "-" + rgb + "-" + x1 +"-" + y1 + "-" + x2 + "-" + y2 + "-!");
    }
    
    // Return the communication format for text
    public String textMessage(String oper, int t, String rgb, int x1, int y1, String text) {
        return (oper + "-" + t + "-" + rgb + "-" + x1 +"-" + y1 + "-" + text + "-!");
    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    public void setG(Graphics g) {
        this.g = (Graphics2D) g;
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub

    }

    // get the paint record
    public ArrayList<String> getRecord(){
        return recordList;
    }
    
    // update the paint record by adding line in record list
    public void update(String line) {
        recordList.add(line);
    }
    
    // clear the record list
    public void clearRecord() {
        recordList.clear();
    }
    // Return the color format for communicating
    private String getColor(Color color) {
        return color.getRed() + "-" + color.getGreen() + "-" + color.getBlue();
    }
}
