// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/05/30
package Server;


import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SaveFrame {

    JFrame frame;
    private JTextField FileName;


    /**
     * Create the application.
     */
    public SaveFrame() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setTitle("Save");
        frame.setBounds(100, 100, 274, 175);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        FileName = new JTextField();
        FileName.setBounds(10, 39, 238, 36);
        frame.getContentPane().add(FileName);
        FileName.setColumns(10);

        JLabel lblNewLabel = new JLabel("Type file name in");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 13));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(10, 10, 238, 19);
        frame.getContentPane().add(lblNewLabel);

        JButton saveBtn = new JButton("Save");
        saveBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                String file = FileName.getText();
                ServerUI.save(file, ServerUI.allListener.getRecord());
            }
            @Override
            public void mouseReleased(MouseEvent e) {
                JOptionPane.showMessageDialog(null,"Saved");
                frame.dispose();
            }
        });
        saveBtn.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        saveBtn.setBounds(10, 85, 238, 29);
        frame.getContentPane().add(saveBtn);
    }
}
