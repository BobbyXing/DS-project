// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/05/30
package Server;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import javax.swing.JPanel;

public class Repaint extends JPanel{



    private ArrayList<String> recordList = new ArrayList<String>();

    public void setList(ArrayList<String> recordList) {
        this.recordList = recordList;
    }

    public void paint(Graphics gr) {
        super.paint(gr);
        draw((Graphics2D) gr, this.recordList);
    }
    public void draw(Graphics2D g, ArrayList<String> recordList) {
        try {
            String[] recordArray = recordList.toArray(new String[recordList.size()]);
            for (String line : recordArray) {
                String[] record = line.split("-");
                int startX, startY, endX, endY, t, red, green, blue;
                Color color;
                if (record[1].equals("!")) {
                    continue;
                }
                switch (record[0]) {
                    case "Line":
                        t = Integer.parseInt(record[1]);
                        g.setStroke(new BasicStroke(t));
                        red = Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color = new Color(red,green,blue);
                        g.setColor(color);
                        startX = Integer.parseInt(record[5]);
                        startY = Integer.parseInt(record[6]);
                        endX = Integer.parseInt(record[7]);
                        endY = Integer.parseInt(record[8]);
                        g.drawLine(startX, startY, endX, endY);
                        break;
                    case "Circle":
                        t = Integer.parseInt(record[1]);
                        g.setStroke(new BasicStroke(t));
                        red = Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color = new Color(red,green,blue);
                        g.setColor(color);
                        startX = Integer.parseInt(record[5]);
                        startY = Integer.parseInt(record[6]);
                        endX = Integer.parseInt(record[7]);
                        endY = Integer.parseInt(record[8]);
                        g.drawOval(startX, startY, Math.abs(endX - startX), Math.abs(endY - startY));
                        break;
                    case "Triangle":
                        t = Integer.parseInt(record[1]);
                        g.setStroke(new BasicStroke(t));
                        red = Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color = new Color(red,green,blue);
                        g.setColor(color);
                        startX = Integer.parseInt(record[5]);
                        startY = Integer.parseInt(record[6]);
                        endX = Integer.parseInt(record[7]);
                        endY = Integer.parseInt(record[8]);
                        g.drawLine((startX + endX) / 2, startY, endX, endY);
                        g.drawLine((startX + endX) / 2, startY, startX, endY);
                        g.drawLine(startX, endY, endX, endY);
                        break;
                    case "Rectangle":
                        t = Integer.parseInt(record[1]);
                        g.setStroke(new BasicStroke(t));
                        red = Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color = new Color(red,green,blue);
                        g.setColor(color);
                        startX = Integer.parseInt(record[5]);
                        startY = Integer.parseInt(record[6]);
                        endX = Integer.parseInt(record[7]);
                        endY = Integer.parseInt(record[8]);
                        g.drawRect(startX, startY, Math.abs(endX - startX), Math.abs(endY - startY));
                        break;
                    case "A":
                        t = Integer.parseInt(record[1]);
                        Font f = new Font(null,Font.PLAIN, t+20);
                        g.setFont(f);
                        red = Integer.parseInt(record[2]);
                        green = Integer.parseInt(record[3]);
                        blue = Integer.parseInt(record[4]);
                        color = new Color(red,green,blue);
                        g.setColor(color);
                        startX = Integer.parseInt(record[5]);
                        startY = Integer.parseInt(record[6]);
                        String text = record[7];
                        g.drawString(text, startX,startY);
                        break;
                    case "Color":
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
