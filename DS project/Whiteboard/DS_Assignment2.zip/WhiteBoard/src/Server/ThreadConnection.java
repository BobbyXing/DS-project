// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/05/30
package Server;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import javax.swing.JOptionPane;




public class ThreadConnection extends Thread{
    public Socket socket;
    public DataInputStream dis; // input from client
    public DataOutputStream dos; // output to client
    @Override
    public void run() {
        try {
            InputStream ins = socket.getInputStream();
            OutputStream ous = socket.getOutputStream();
            dis = new DataInputStream(ins);
            dos = new DataOutputStream(ous);
            String inputString;
            while ((inputString =  dis.readUTF()) != null){
                String[] strList = inputString.split("-", 2);
                // if the request is "JoinIn" 
                // send draw list, chat list, user name lists to all users
                if (strList[0].equals("JoinIn")) {
                    ConnectionManager.sendList(ServerUI.allListener.getRecord());
                    ConnectionManager.sendToAll("Chat-" + ServerUI.allChat);
                    ServerUI.setListData(Server.usernames.toArray());
                    ConnectionManager.sendToAll("Newone-Hello");
                    ConnectionManager.sendUserName(Server.usernames);
                // if the request is "Ask"
                } else if (strList[0].equals("Ask")){
                    String username = strList[1];
                    // user exist, remove connection and tell the guest
                    if (Server.usernames.contains(username)) {
                    	Server.connections.remove(this);
                        dos.writeUTF("Ask-Dup");
                    } else {
                        int option = JOptionPane.showConfirmDialog(ServerUI.frame, username +
                                " wants to share your whiteboard", "Confirm",JOptionPane.INFORMATION_MESSAGE);
                        // if click yes, send allowed back
                        if (option == JOptionPane.YES_OPTION) {
                            Server.guestName.add(username);
                            Server.usernames.add(username);

                            dos.writeUTF("Ask-Allowed");
                            dos.flush();
                        // otherwise send rejected back
                        } else {
                            dos.writeUTF("Ask-Rejected");
                            dos.flush();
                            Server.connections.remove(this);
                        }
                    }
                // if request is Paint, update the paint list and send the list to all guests
                } else if (strList[0].equals("Paint")) {
                    ServerUI.allListener.update(strList[1]);
                    ConnectionManager.sendList(ServerUI.allListener.getRecord());
                    ServerUI.drawArea.repaint();
                // if request is Chat, update update the chat and send it to all guests
                } else if (strList[0].equals("Chat")) {
                    ServerUI.allChat = strList[1];
                    ServerUI.setChat(ServerUI.allChat);
                    ConnectionManager.sendToAll("Chat-" + ServerUI.allChat);
                // if request is Close, remove the guest, and update the user name list
                } else if (strList[0].equals("Close")) {
                    String selected = strList[1].toString();
                    for (int i = 0; i < Server.connections.size(); i++) {
                        if (selected.equals(Server.guestName.get(i))) {
                            ThreadConnection rmConn = Server.connections.get(i);
                            Server.connections.remove(rmConn);
                            Server.usernames.remove(selected);
                            Server.guestName.remove(selected);
                            Object[] a = Server.usernames.toArray();
                            ServerUI.setListData(Server.usernames.toArray());
                            JOptionPane.showMessageDialog(ServerUI.frame, selected + " has leave!");
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Client Disconnect, Closed...");
        }
        super.run();
    }
    // make connection to each client based on socket
    public ThreadConnection(Socket socket) {
        this.socket = socket;
    }
}
