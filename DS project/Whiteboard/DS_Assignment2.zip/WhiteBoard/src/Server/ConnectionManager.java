// Student Name: Pengbo Xing
// Student ID: 1287557
// Date: 2022/05/30
package Server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ConnectionManager {
	
	// send a single message to all guests 
    public synchronized static void sendToAll(String message) throws IOException {

        if (!Server.connections.isEmpty()) {
            for (int i = 0; i < Server.connections.size(); i++) {
                ThreadConnection st = Server.connections.get(i);
                st.dos.writeUTF(message);
                st.dos.flush();
            }
        }
    }
    
    // send the Paint list to all guests by sending one message by one message
    public synchronized static void sendList(ArrayList<String> recordList) throws IOException{
        String[] recordArray = recordList.toArray(new String[recordList.size()]);
        for (String message : recordArray) {
            for (int i = 0; i < Server.connections.size(); i++) {
                ThreadConnection st = Server.connections.get(i);
                st.dos.writeUTF("Paint-" + message);
                st.dos.flush();
            }
        }
    }

    // sending the User list to all guests by sending one user by one user
    public synchronized static void  sendUserName(List<String> usernames) throws IOException {
        String[] recordArray = usernames.toArray(new String[usernames.size()]);
        for (String message : recordArray) {
            for (int i = 0; i < Server.connections.size(); i++) {
                ThreadConnection st = Server.connections.get(i);
                st.dos.writeUTF("User-" + message);
                st.dos.flush();
            }
        }
    }
}
